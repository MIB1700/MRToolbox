autowatch = 1;

//use:
function TEST() {

  var ys = [100, 200, 150, 100, 0];
  var xs = [10, 20, 30, 40, 50];

  var spline = new Spline(xs, ys);
  spline.done();

  for (var x = 100; x <= 500; x++) {
      //query y AT x
      post("x: ", (x * 0.1), " y: ", spline.at(x * 0.1), "\n");
  }
}
/********************************/
/********************************/
post("Cubic Spine Interpolator v.1 \n");
post("    by Martin Ritter \n");
post("      original code from https://github.com/morganherlocker/cubic-spline \n");
function Spline(_xs, _ys) {

      this.xs = _xs;
      this.ys = _ys;
      this.ks;

    this.done = function (){

        this.ks = this.getNaturalKs(new Float64Array(this.xs.length));
    };

    this.getNaturalKs = function(ks) {
      const n = this.xs.length - 1;
      const A = zerosMat(n + 1, n + 2);

      for (
        var i = 1;
        i < n;
        i++ // rows
      ) {
        A[i][i - 1] = 1 / (this.xs[i] - this.xs[i - 1]);
        A[i][i] =
          2 *
          (1 / (this.xs[i] - this.xs[i - 1]) + 1 / (this.xs[i + 1] - this.xs[i]));
        A[i][i + 1] = 1 / (this.xs[i + 1] - this.xs[i]);
        A[i][n + 1] =
          3 *
          ((this.ys[i] - this.ys[i - 1]) /
            ((this.xs[i] - this.xs[i - 1]) * (this.xs[i] - this.xs[i - 1])) +
            (this.ys[i + 1] - this.ys[i]) /
              ((this.xs[i + 1] - this.xs[i]) * (this.xs[i + 1] - this.xs[i])));
      }

      A[0][0] = 2 / (this.xs[1] - this.xs[0]);
      A[0][1] = 1 / (this.xs[1] - this.xs[0]);
      A[0][n + 1] =
        (3 * (this.ys[1] - this.ys[0])) /
        ((this.xs[1] - this.xs[0]) * (this.xs[1] - this.xs[0]));

      A[n][n - 1] = 1 / (this.xs[n] - this.xs[n - 1]);
      A[n][n] = 2 / (this.xs[n] - this.xs[n - 1]);
      A[n][n + 1] =
        (3 * (this.ys[n] - this.ys[n - 1])) /
        ((this.xs[n] - this.xs[n - 1]) * (this.xs[n] - this.xs[n - 1]));

      return solve(A, ks);
    };
    /********************************/
    /**
     * inspired by https://stackoverflow.com/a/40850313/4417327
     */
    this.getIndexBefore = function(target) {
      var low = 0;
      var high = this.xs.length;
      var mid = 0;
      while (low < high) {
        mid = Math.floor((low + high) / 2);
        if (this.xs[mid] < target && mid !== low) {
          low = mid;
        } else if (this.xs[mid] >= target && mid !== high) {
          high = mid;
        } else {
          high = low;
        }
      }
      return low + 1;
    };
    /********************************/
    this.at = function(x) {
      var i = this.getIndexBefore(x);
      const ksL = this.ks;//this.ks;
      const t = (x - this.xs[i - 1]) / (this.xs[i] - this.xs[i - 1]);
      const a = ksL[i - 1] * (this.xs[i] - this.xs[i - 1]) - (this.ys[i] - this.ys[i - 1]);
      const b = -ksL[i] * (this.xs[i] - this.xs[i - 1]) + (this.ys[i] - this.ys[i - 1]);
      const q = (1 - t) * this.ys[i - 1] + t * this.ys[i] + t * (1 - t) * (a * (1 - t) + b * t);
      return q;
    };
}
/********************************/
  function solve(A, ks) {
    const m = A.length;
    var h = 0;
    var k = 0;
    while (h < m && k <= m) {
      var i_max = 0;
      var max = -Infinity;
      for (var i = h; i < m; i++) {
        const v = Math.abs(A[i][k]);
        if (v > max) {
          i_max = i;
          max = v;
        }
      }

      if (A[i_max][k] === 0) {
        k++;
      } else {
        swapRows(A, h, i_max);
        for (var i = h + 1; i < m; i++) {
          const f = A[i][k] / A[h][k];
          A[i][k] = 0;
          for (var j = k + 1; j <= m; j++) A[i][j] -= A[h][j] * f;
        }
        h++;
        k++;
      }
    }

    for (
      var i = m - 1;
      i >= 0;
      i-- // rows = columns
    ) {
      var vv = 0;
      if (A[i][i]) {
        vv = A[i][m] / A[i][i];
      }
      ks[i] = vv;
      for (
        var j = i - 1;
        j >= 0;
        j-- // rows
      ) {
        A[j][m] -= A[j][i] * vv;
        A[j][i] = 0;
      }
    }
    return ks;
  }
/********************************/
  function zerosMat(r, c) {
    const A = [];
    for (var i = 0; i < r; i++) A.push(new Float64Array(c));
    return A;
  }
/********************************/
  function swapRows(m, k, l) {
    var p = m[k];
    m[k] = m[l];
    m[l] = p;
  }